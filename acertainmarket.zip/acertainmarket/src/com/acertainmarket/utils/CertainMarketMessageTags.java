package com.acertainmarket.utils;

public enum CertainMarketMessageTags {
	ADD_ITEMS, QUERY_ITEMS, BID, SWITCH_EPOCH;
}
